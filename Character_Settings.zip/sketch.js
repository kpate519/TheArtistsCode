//This is where we will be loading all our pixel art and scenes
let player;
let select_photo;
let Scene0;
function preload(){
  
  //This is the player art
  player = loadImage('Player/Player_Down_Idle.png');
  Player_Side_I = loadImage('Player/Player_Side_Idle.png');
  Player_Down_I = loadImage('Player/Player_Down_Idle.png');
  Player_Up_I = loadImage('Player/Player_Up_Idle_2.png');
  Player_Up= loadImage('Player/Player_Up.gif');
  Player_Down= loadImage('Player/Player_Down.gif');
  Player_Side= loadImage('Player/Player_Side_Move.gif');
  
  select_photo=loadImage('Sprites/Heart.png');
  
  //This is other character art
  
  
  //This is the where our scene art will be
  
  
  
  //Scene0sds/Scene0.gif');

    Scene0=loadImage('Sprites/Scene0.gif');

  
}


//Controls the entire canvas in which you are in
var scene=0;

var direction= "down";

let character_speed = 4;

let x = 50;
let y = 50;
let character_size=55;

//Time Calculation

var canvasSize=500;//Holds the canvas size

var frame=40;//Controls the framerate of the game



//This section is used to keep track of what items are and what they do



//IMPORTANT DON'T FORGET TO APPEND ITEM COUNT
var item_count=3;
var items=["______","Snack","MemoryFragment"];//This lists the item name that we can find
var usable=[false,true,false];//This tells if that item at that index is usable
var effect=[0,10,0];//This tell what effect it has if usable it true on that index
var description=["This is Nothing","A Nostalgic Snack- Heal 10","This Restores Memory"];


//Scene 0 variables(IMPORTANT FOR PROGRESSION)
var scene1locked=true;
var scene2locked=true;
var scene3locked=true;

var wallinteraction=false;
var tutorial=true;
var tut=false;




var choice=1;//Used for navigating the menu

var inventory=["______","______","______","______","______"];//Used to store items(Hit 'M' To Access)


//This stores the players stats on setup
var hp=20;
var maxhp=20;

var level=1;

//You can use these two variable to change(I need to later update the if statements for walking to also help deal with the Scene Alterations of the Canvas so they don't stop walking while in the middle of the canvas that was altered)


let SceneAlterX=0;
let SceneAlterY=0;

function setup() {
  createCanvas(canvasSize+SceneAlterX,canvasSize+SceneAlterY);
  fill(0);
  

  frameRate(frame);
}

  var spawn=true;//This Variable helps define whether or not to respawn the player

var mine=0;
var sec=0;

var menu=false;

var movement=true;//Controls whether the character can move or not

var STOP=true;//Tells whether the player stopped moving

function draw() {
  background(200);
  // Update x and y if an arrow key is pressed.
  fill(0);
  
  if(hp>maxhp){
    hp=maxhp;
  }
  
  
  
  
  
  
  
  
   if(sec==60){
     mine+=1;
     sec=0;
   }
  
  if(frameCount%frame==0){
    sec+=1;
  }
  
      
  
  
   //This is where our scenes should be as to not draw over the character and add any functions that coudl affect the stage
  
  if(scene ==0 ){
    image(Scene0,0,0,canvasSize,canvasSize);
    
    
    if(spawn==true){//This spawns the player at the middle of the canvas if you want to change where they spawn, you can steal this function and place it anywhere in your scene and just change the x and y coordinates
    x = width/2;
    y = height/2-150;
    spawn = false;
  }
    
    if((x<142 &&x>0-character_size)&&(y>162&&y<canvasSize+character_size)&&(direction=="left"||direction=="right")){
      x+=character_speed*5;
      
    }
    
    else if((x<142 &&x>0-character_size)&&(y>162&&y<canvasSize+character_size)&&(direction=="down"||direction=="up")){
      y-=character_speed*5;
      
    }
    
    
    
    if((x<canvasSize+character_size &&x>350)&&(y>162&&y<canvasSize+character_size)&&(direction=="left"||direction=="right")){
      x-=character_speed*5;
      
    }
    
    else if((x<canvasSize+character_size &&x>350)&&(y>162&&y<canvasSize+character_size)&&(direction=="down"||direction=="up")){
      y-=character_speed*5;
      
    }
    
    
    if(y<16){
      y+=character_speed*2;
    }
    
    
    
    
    
    
    if(scene1locked==true){
      fill(128,0,128);
      rect(0,68,80,150);
      fill(0);
      
      if(x<78&&x>0-character_size){
        x+=character_speed*5;
      }
    }
    
    else if(scene1locked==false){
      if(x>0-character_size&&x< 30){
        scene=1;
      }
    }

    if(scene2locked==true){
      fill(128,0,128);
      rect(canvasSize-70,68,70,150);
      fill(0);
      
      if(x<canvasSize-character_size&&x>395){
        x-=character_speed*5;
      }
    }
    
    else if(scene2locked==false){
      if(y<canvasSize&&y>canvasSize/2+50){
        scene=2;
      }
      
    }

      
    if(scene3locked==true){
      fill(128,0,128);
      rect(canvasSize/2-100,canvasSize/2+50,235,200);
      fill(0);
      
      if(y<canvasSize&&y>canvasSize/2){
        y-=character_speed*5;
      }
    }
    
    else if(scene3locked==false){
      if(x<canvasSize-character_size&&x>420){
        scene=3;
      }
    }
    
    //Checks if walla can be unlocked or not given holding memory fragment and unlocked scene order
    if(wallinteraction==true){
      

      fill(255);

      rect(10,canvasSize-110,canvasSize-30,90);//Bottom Bar of menu

      fill(0);

      rect(20,canvasSize-100,canvasSize-50,70);//Bottom Bar of menu

      fill(255);
      
      //Goes through Listed All Possible Items till It finds a match
      var fragFound=false;
    for(var i=0;i<5;i++){
      
      if(inventory[i]=="MemoryFragment"){
        fragFound=true;
        
      }
    }
      
      
      if(fragFound==true){
        if(x>=70&&x<=130){
        text("You have used a memory fragment",canvasSize/2-130,canvasSize-60);
        
      }
      
      else if(y>=220&&y<=250&&scene1locked==true){
        text("You believe you have to unlock another piece of memory first",canvasSize/2-130,canvasSize-60);
        
      }
      
      else if(y>=220&&y<=250&&scene1locked==false){
        text("You have used a memory fragment",canvasSize/2-130,canvasSize-60);
        
      }
        
      else if(x>=370&&x<=395&&scene2locked==false){
        text("You have used a memory fragment",canvasSize/2-130,canvasSize-60);
        
      }
        
        else if(x>=370&&x<=395&&scene2locked==true){
        text("You believe you have to unlock another piece of memory first",canvasSize/2-130,canvasSize-60);
        
      }
        
        
      }//End of if memory fragment is true
      else{
        text("You currently don't have a memory fragment",canvasSize/2-130,canvasSize-60);
      }
      
    
  
    fill(0);
      
    }//End of Wall interaction check
    
    
    
      
      
      
      
    
    
    
  }//End of Scene 0
    
    
  
  
  if(direction!="left"){//This whole if statement is used to tell whether or not to flip the image or not when they are going left
    image(player,x,y,character_size,character_size);
  }
  
  else{//IF they are going left, they will flip the current image connect to the player with the scale function to make the picture walk or stop when looking left(basically they are now looking left...)
    
    push();
    scale(-1,1);
   
    
    image(player,-x-40,y,character_size,character_size);
    pop();
  }
  
  
 
  
  
  //Important detail keeping information, You can add stuff here to appear on screen if you want the test any variable and see if it working, just comment out the star thing to the upper left of this comment to do so
   text("Direction: " + direction,50,50);//Gives the direction the character is facing
  text("Time: " + mine+":"+sec,200,50);
  text("Framerate: " + round(frameRate()),300,50);
  text("Framecount: " + frameCount,300,75);
  
  text("X: " + x,300,100);
  text("Y: " + y,300,130);
  
  
  //This is where our character movements will be stored
  if(movement==true){
    
    //The x and y parts of the if statement are to assure the player won't walk out of canvas
    
    //If they're pressing both left and down
    if (((keyIsDown(LEFT_ARROW) === true|| keyIsDown(65) === true)&&(keyIsDown(DOWN_ARROW) === true|| keyIsDown(83) === true))&&(       y<canvasSize-character_size&&x>0)) {
      x -= character_speed;
      y+= character_speed;
      direction="left";
      
      player=Player_Side;
      STOP=false;
    }
    
    
    //If they're pressing both left and up
    else if (((keyIsDown(LEFT_ARROW) === true|| keyIsDown(65) === true)&&(keyIsDown(UP_ARROW) === true|| keyIsDown(87) === true))&&(       y>0&&x>0)) {
      x -= character_speed;
      y-= character_speed;
      direction="left";
      
      player=Player_Side;
      STOP=false;
    }
  //Player is just moving left
    else if ((keyIsDown(LEFT_ARROW) === true|| keyIsDown(65) === true)&&       x>0) {
      x -= character_speed;
      direction="left";
      
      player=Player_Side;
      STOP=false;
    }
    
    //Playe ris moving both right and up
    else if (((keyIsDown(RIGHT_ARROW) === true || keyIsDown(68) ==     true)&&(keyIsDown(UP_ARROW) === true|| keyIsDown(87) === true))&&(y>0&&x<canvasSize-character_size)) {
      x += character_speed;
        y-= character_speed;
      player=Player_Side;
      direction="right";
      STOP=false;
    }
    //Player is moving both right and down
    else if (((keyIsDown(RIGHT_ARROW) === true || keyIsDown(68) ==     true)&&(keyIsDown(DOWN_ARROW) === true|| keyIsDown(83) === true))&&(y<canvasSize-character_size&&x<canvasSize-character_size)) {
      x += character_speed;
      y+= character_speed;
      player=Player_Side;
      direction="right";
      STOP=false;
    }
    
    //Player is moving only right
    else if ((keyIsDown(RIGHT_ARROW) === true || keyIsDown(68) ==     true)&&x<canvasSize-character_size) {
      x += character_speed;
      player=Player_Side;
      direction="right";
      STOP=false;
    }
    
    
    //Player is movign true up
    else if ((keyIsDown(UP_ARROW) === true|| keyIsDown(87) === true) && y>0) {
      y -= character_speed;
      player=Player_Up;
      direction="up";
      STOP=false;
    }
    //Player is moving true Down
    else if ((keyIsDown(DOWN_ARROW) === true|| keyIsDown(83) === true) &&y<canvasSize-character_size) {
      y += character_speed;
      direction="down"
      player=Player_Down;
      STOP=false;
    }
    
    
    else{STOP=true;
        }
    

    
    
  }//Movement if statement
  
  
  //When interacting with an object or something within the scene is happen, you can set the player with 'STOP=true' to make them pause into the idle animation towards the last direction they were facing
  if(STOP==true){
      
      
      if(direction=="right"){
        player=Player_Side_I;
      }
      
      else if(direction=="left"){
        player=Player_Side_I;
      }
      else if(direction=="up"){
        player=Player_Up_I;}
      
      else if(direction=="down"){
        player=Player_Down_I;
      }
    }
  
  
  
  //This is the Menu Code Which can bee seen from Pressing 'M'
  if(movement==false && menu==true){
    
   
    
    fill(255);
    
    rect(10,canvasSize-110,canvasSize-30,90);//Bottom Bar of menu
    
    fill(0);
    
    rect(20,canvasSize-100,canvasSize-50,70);//Bottom Bar of menu
    
    fill(255);
    //Stats stuff
    
    text("PAUSED            Time: "+mine+":"+sec,70,canvasSize-50);
    fill(0,255,0);
    text("Level: "+level,70,canvasSize-70);
    fill(255,0,0);
    text("HP:  "+hp+"/"+maxhp,150,canvasSize-70);
     
    fill(255);
    
    rect(10,20,170,canvasSize-canvasSize/2+20);//Side Bar
    
    
    fill(0);
    rect(20,30,150,canvasSize-canvasSize/2);//Side bar Options
    
    
    fill(255,255,0);
    
    ///This Shows the Inventory from which player collected
    text("Inventory",70,70);
    if(choice==1){
      image(select_photo,40,90,20,10);
      fill(255,255,0);
    }
    else{
      fill(255);
    }
    text(inventory[0],70,90);//First Item Slot
    if(choice==2){
      fill(255,255,0);
      image(select_photo,40,120,20,10);
    }
    else{
      fill(255);
    }
    text(inventory[1],70,120);//Second Items Slot
    if(choice==3){
      fill(255,255,0);
      image(select_photo,40,150,20,10);
    }
    else{
      fill(255);
    }
    text(inventory[2],70,150);//Third Items Slot
    if(choice==4){
      fill(255,255,0);
      image(select_photo,40,180,20,10);
    }
    else{
      fill(255);
    }
    text(inventory[3],70,180);//Fourth Item Slot
    if(choice==5){
      fill(255,255,0);
      image(select_photo,40,210,20,10);
     
           
    }
    else{
      fill(255);
    }
    text(inventory[4],70,210);//Fifth Item Slot
     
    fill(255);
    
    //Goes through Listed All Possible Items till It finds a match
    for(var i=0;i<item_count;i++){
      
      if(inventory[choice-1]==items[i]){
      
      text("Description:  '"+description[i]+"'",canvasSize/2-30,canvasSize-60);
        //if item exists and is usable, it will consume that inventory item And reset that slot of a Blank inventory Slot
        if(keyCode==69&&(menu==true&&movement==false)&&(usable[i]==true)){
          hp+=effect[i];
          inventory[i]="______";
      
    }
      }
    }
    
    
    
    
    
    fill(0);
    
    
    
    
    
  }//End of Menu Movement

  
        
  
}//This is the end of the DRAW Function



//This shows all the possible Single press(Non Hold Down) keys that the user can press that lets them interact with the scene outside of inventory( Such as hitting menu and 'E' TO interact)
function keyPressed() {
 
    //This is to enter the menu by hitting 'M'
    if(key==='m'&&(menu===false&&movement===true)){
      STOP=true;
      movement=false;
      menu=true;
      choice=1;
    }
    //This is a repeat of the above function but allows the user to leave the menu and move again
    else if(key==='m'&&(menu===true&&movement===false)){
      movement=true;
      menu=false;
      choice=1;
    }
  //This is the movement keys used to move up through the menu
    if(movement===false&&menu==true){
      if(keyCode===83||keyCode===40){
        if(choice!=5){
          choice+=1;}
      }
      //This is the movement keys used to move down through the menu
      if(keyCode===87||keyCode===38){
        if(choice!=1){
          choice-=1;}
      }
       
       }
  
  
  
  //This is the Scene interaction code for if the user wants to interact with scene objects by hitting 'E', You can copy and past this if statement to work with a numbered scene by a certain x and y coordinate so the user can get specific text options, movement to pause, and innerworld activity at certain areas of the game
  
  //This Checks the condition of the Scene barrier
  if(keyCode==69&&scene==0&&scene1locked==true&&wallinteraction==false&&(x>=70&&x<=130)){
    STOP=true;
    
    movement=false
    wallinteraction=true;
    
    
    }
  else if(keyCode==69&&scene==0&&scene2locked==true&&wallinteraction==false&&(y>=220&&y<=245)){
    STOP=true;
    
    movement=false
    wallinteraction=true;
    
    
    }
  
  else if(keyCode==69&&scene==0&&scene3locked==true&&wallinteraction==false&&(x>=370&&x<=395)){
    STOP=true;
    
    movement=false
    wallinteraction=true;
    
    
    }
  
  //Clears out the inventory space of Mmeory Fragment after usage and leaves the text box interaction
  else if(wallinteraction==true&&keyCode==69&&scene==0){
    
    for(var i=0; i< 5;i++){
      if(inventory[i]=="MemoryFragment"&&(x>=70&&x<=130)){
        
        inventory[i]="______";
          scene1locked=false;
        }
      
      else if(inventory[i]=="MemoryFragment"&&(y>=2200&&y<=canvasSize/2)&&scene1locked==false){
        
        inventory[i]="______";
          scene2locked=false;
        }
      
      else if(inventory[i]=="MemoryFragment"&&(x>=370&&x<=395)&&scene2locked==false){
        
        inventory[i]="______";
          scene3locked=false;
        }
    
    }
    movement=true;
    STOP=false;
    wallinteraction=false;
    
  }
  
    
  
}



